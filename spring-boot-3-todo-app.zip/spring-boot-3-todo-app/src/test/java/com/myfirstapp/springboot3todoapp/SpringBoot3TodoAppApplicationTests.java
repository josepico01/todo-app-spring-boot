package com.myfirstapp.springboot3todoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot3TodoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
